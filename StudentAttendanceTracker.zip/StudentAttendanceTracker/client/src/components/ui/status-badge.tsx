import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";

const statusBadgeVariants = cva(
  "inline-flex items-center rounded-full px-2 py-1 text-xs font-medium",
  {
    variants: {
      variant: {
        present: "bg-green-100 text-green-800",
        absent: "bg-red-100 text-red-800",
        late: "bg-yellow-100 text-yellow-800",
        pending: "bg-blue-100 text-blue-800",
        approved: "bg-green-100 text-green-800",
        declined: "bg-red-100 text-red-800",
      },
    },
    defaultVariants: {
      variant: "present",
    },
  }
);

export interface StatusBadgeProps
  extends React.HTMLAttributes<HTMLSpanElement>,
    VariantProps<typeof statusBadgeVariants> {
  status?: string;
}

export function StatusBadge({
  className,
  variant,
  status,
  ...props
}: StatusBadgeProps) {
  // If status is provided, use it to determine the variant
  const derivedVariant = status
    ? (status.toLowerCase() as "present" | "absent" | "late" | "pending" | "approved" | "declined")
    : variant;

  return (
    <span
      className={cn(statusBadgeVariants({ variant: derivedVariant }), className)}
      {...props}
    >
      {status || variant?.charAt(0).toUpperCase() + variant?.slice(1)}
    </span>
  );
}
