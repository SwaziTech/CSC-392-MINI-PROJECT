import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";

interface TakeAttendanceModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

interface Student {
  id: number;
  studentId: string;
  name: string;
  email: string | null;
  classId: number;
}

interface Class {
  id: number;
  name: string;
  grade: string;
  section: string;
}

interface StudentAttendance {
  studentId: number;
  status: "present" | "absent" | "late";
  note?: string;
}

export function TakeAttendanceModal({ open, onOpenChange }: TakeAttendanceModalProps) {
  const { toast } = useToast();
  const { user } = useAuth();
  const [selectedClass, setSelectedClass] = useState<string>("");
  const [date, setDate] = useState<string>("");
  const [attendance, setAttendance] = useState<Record<number, StudentAttendance>>({});
  const [noteStudentId, setNoteStudentId] = useState<number | null>(null);
  const [note, setNote] = useState<string>("");

  useEffect(() => {
    // Set today's date as default
    const today = new Date();
    const formattedDate = today.toISOString().split('T')[0];
    setDate(formattedDate);
  }, []);

  // Fetch classes
  const { data: classes, isLoading: classesLoading } = useQuery<Class[]>({
    queryKey: ['/api/classes'],
    enabled: open,
  });

  // Fetch students based on selected class
  const { data: students, isLoading: studentsLoading } = useQuery<Student[]>({
    queryKey: ['/api/classes', selectedClass, 'students'],
    queryFn: async () => {
      if (!selectedClass) return [];
      const res = await fetch(`/api/classes/${selectedClass}/students`);
      if (!res.ok) throw new Error('Failed to fetch students');
      return res.json();
    },
    enabled: !!selectedClass && open,
  });

  // Initialize attendance when students are loaded
  useEffect(() => {
    if (students && students.length > 0) {
      const initialAttendance: Record<number, StudentAttendance> = {};
      students.forEach(student => {
        initialAttendance[student.id] = { studentId: student.id, status: "present" };
      });
      setAttendance(initialAttendance);
    }
  }, [students]);

  const handleStatusChange = (studentId: number, status: "present" | "absent" | "late") => {
    setAttendance(prev => ({
      ...prev,
      [studentId]: { ...prev[studentId], studentId, status }
    }));
  };

  const handleNoteOpen = (studentId: number) => {
    setNoteStudentId(studentId);
    setNote(attendance[studentId]?.note || "");
  };

  const handleNoteClose = () => {
    if (noteStudentId) {
      setAttendance(prev => ({
        ...prev,
        [noteStudentId]: { ...prev[noteStudentId], note }
      }));
    }
    setNoteStudentId(null);
    setNote("");
  };

  const saveAttendanceMutation = useMutation({
    mutationFn: async (data: any) => {
      return await apiRequest('POST', '/api/attendance/bulk', data);
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Attendance saved successfully",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/attendance'] });
      queryClient.invalidateQueries({ queryKey: ['/api/stats/today'] });
      queryClient.invalidateQueries({ queryKey: ['/api/dashboard/recent-classes'] });
      onOpenChange(false);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to save attendance: " + (error instanceof Error ? error.message : "Unknown error"),
        variant: "destructive",
      });
    }
  });

  const handleSaveAttendance = () => {
    if (!selectedClass || !date || !user) {
      toast({
        title: "Error",
        description: "Please select a class and date",
        variant: "destructive",
      });
      return;
    }

    const attendanceData = Object.values(attendance).map(item => ({
      studentId: item.studentId,
      classId: parseInt(selectedClass),
      date: new Date(date).toISOString(),
      status: item.status,
      note: item.note || null,
      recordedBy: user.id
    }));

    saveAttendanceMutation.mutate({ attendances: attendanceData });
  };

  const handleMarkAll = (status: "present" | "absent" | "late") => {
    if (!students) return;
    
    const newAttendance: Record<number, StudentAttendance> = {};
    students.forEach(student => {
      newAttendance[student.id] = { 
        ...attendance[student.id], 
        studentId: student.id, 
        status 
      };
    });
    setAttendance(newAttendance);
  };

  // Format today's date for the UI
  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString('en-US', { 
      weekday: 'long', 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    });
  };

  const today = new Date().toISOString().split('T')[0];

  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="sm:max-w-[700px]">
          <DialogHeader>
            <DialogTitle className="text-lg font-semibold">Take Attendance</DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
            <div>
              <Label htmlFor="class" className="block text-sm font-medium text-gray-700 mb-1">Class</Label>
              <Select value={selectedClass} onValueChange={setSelectedClass}>
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Select a class" />
                </SelectTrigger>
                <SelectContent>
                  {classesLoading ? (
                    <div className="p-2 text-center">Loading...</div>
                  ) : classes && classes.length > 0 ? (
                    classes.map(cls => (
                      <SelectItem key={cls.id} value={cls.id.toString()}>
                        {cls.name} ({cls.grade}-{cls.section})
                      </SelectItem>
                    ))
                  ) : (
                    <div className="p-2 text-center">No classes available</div>
                  )}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="date" className="block text-sm font-medium text-gray-700 mb-1">Date</Label>
              <Input
                type="date"
                id="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                max={today}
              />
            </div>
          </div>

          <div className="border rounded-lg mb-6">
            <div className="bg-gray-50 px-4 py-3 border-b">
              <div className="flex items-center justify-between">
                <h4 className="text-sm font-medium text-gray-700">Student List</h4>
                <div className="flex items-center">
                  <span className="text-xs text-gray-500 mr-2">Mark all as:</span>
                  <Button 
                    size="sm" 
                    variant="outline" 
                    className="text-green-600 border-green-500 hover:bg-green-50 mr-1"
                    onClick={() => handleMarkAll("present")}
                  >
                    Present
                  </Button>
                  <Button 
                    size="sm" 
                    variant="outline" 
                    className="text-red-600 border-red-500 hover:bg-red-50"
                    onClick={() => handleMarkAll("absent")}
                  >
                    Absent
                  </Button>
                </div>
              </div>
            </div>
            
            <div className="max-h-64 overflow-y-auto">
              {studentsLoading ? (
                <div className="p-6 text-center">
                  <div className="animate-spin h-6 w-6 border-4 border-primary border-t-transparent rounded-full mx-auto"></div>
                  <p className="mt-2 text-gray-500">Loading students...</p>
                </div>
              ) : !selectedClass ? (
                <div className="p-6 text-center text-gray-500">
                  Please select a class to view students
                </div>
              ) : students && students.length > 0 ? (
                <table className="w-full">
                  <thead className="bg-gray-50 sticky top-0">
                    <tr>
                      <th className="text-left py-2 px-4 text-xs font-medium text-gray-500 uppercase tracking-wider">Student</th>
                      <th className="text-center py-2 px-4 text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                      <th className="text-right py-2 px-4 text-xs font-medium text-gray-500 uppercase tracking-wider">Note</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200">
                    {students.map(student => (
                      <tr key={student.id}>
                        <td className="py-3 px-4">
                          <div className="flex items-center">
                            <div className="w-8 h-8 rounded-full bg-gray-300 flex items-center justify-center mr-3">
                              <span className="text-sm font-medium text-gray-600">
                                {student.name.charAt(0)}
                              </span>
                            </div>
                            <div>
                              <p className="text-sm font-medium text-gray-800">{student.name}</p>
                              <p className="text-xs text-gray-500">{student.studentId}</p>
                            </div>
                          </div>
                        </td>
                        <td className="py-3 px-4">
                          <RadioGroup
                            value={attendance[student.id]?.status || "present"}
                            onValueChange={(value) => handleStatusChange(
                              student.id, 
                              value as "present" | "absent" | "late"
                            )}
                            className="flex justify-center space-x-2"
                          >
                            <div className="flex items-center space-x-1">
                              <RadioGroupItem 
                                value="present" 
                                id={`present-${student.id}`} 
                                className="text-green-500 border-green-300 focus:ring-green-500"
                              />
                              <Label htmlFor={`present-${student.id}`} className="text-sm text-gray-600">Present</Label>
                            </div>
                            <div className="flex items-center space-x-1">
                              <RadioGroupItem 
                                value="absent" 
                                id={`absent-${student.id}`} 
                                className="text-red-500 border-red-300 focus:ring-red-500"
                              />
                              <Label htmlFor={`absent-${student.id}`} className="text-sm text-gray-600">Absent</Label>
                            </div>
                            <div className="flex items-center space-x-1">
                              <RadioGroupItem 
                                value="late" 
                                id={`late-${student.id}`} 
                                className="text-yellow-500 border-yellow-300 focus:ring-yellow-500"
                              />
                              <Label htmlFor={`late-${student.id}`} className="text-sm text-gray-600">Late</Label>
                            </div>
                          </RadioGroup>
                        </td>
                        <td className="py-3 px-4 text-right">
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            onClick={() => handleNoteOpen(student.id)}
                            className="text-gray-500 hover:text-primary"
                          >
                            <i className="fas fa-sticky-note"></i>
                            {attendance[student.id]?.note ? (
                              <span className="ml-1 text-xs text-primary">✓</span>
                            ) : null}
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              ) : (
                <div className="p-6 text-center text-gray-500">
                  No students in this class
                </div>
              )}
            </div>
          </div>

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => onOpenChange(false)}
              disabled={saveAttendanceMutation.isPending}
            >
              Cancel
            </Button>
            <Button
              onClick={handleSaveAttendance}
              disabled={!selectedClass || studentsLoading || saveAttendanceMutation.isPending}
            >
              {saveAttendanceMutation.isPending ? (
                <>
                  <span className="animate-spin mr-2">↻</span>
                  Saving...
                </>
              ) : (
                "Save Attendance"
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Note dialog */}
      <Dialog open={noteStudentId !== null} onOpenChange={() => noteStudentId && handleNoteClose()}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Add Note</DialogTitle>
          </DialogHeader>
          <div className="py-4">
            <Label htmlFor="note" className="text-sm font-medium text-gray-700 mb-2">
              Note for {students?.find(s => s.id === noteStudentId)?.name || "student"}
            </Label>
            <textarea
              id="note"
              className="w-full rounded-md border border-gray-300 p-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary"
              rows={4}
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="Add a note about this student's attendance..."
            ></textarea>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={handleNoteClose}
            >
              Save Note
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
