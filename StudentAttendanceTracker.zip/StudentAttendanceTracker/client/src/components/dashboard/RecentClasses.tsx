import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";

interface RecentClass {
  id: number;
  name: string;
  grade: string;
  section: string;
  present: number;
  absent: number;
  late: number;
  total: number;
}

export function RecentClasses() {
  const { data, isLoading } = useQuery<RecentClass[]>({
    queryKey: ['/api/dashboard/recent-classes'],
  });

  const getIconClass = (className: string) => {
    const classNameLower = className.toLowerCase();
    if (classNameLower.includes('math')) return 'fas fa-book bg-blue-100 text-primary';
    if (classNameLower.includes('biology') || classNameLower.includes('science')) return 'fas fa-flask bg-green-100 text-green-600';
    if (classNameLower.includes('english') || classNameLower.includes('language')) return 'fas fa-language bg-purple-100 text-purple-600';
    if (classNameLower.includes('history')) return 'fas fa-history bg-red-100 text-red-600';
    if (classNameLower.includes('art')) return 'fas fa-palette bg-yellow-100 text-yellow-600';
    if (classNameLower.includes('music')) return 'fas fa-music bg-indigo-100 text-indigo-600';
    // Default
    return 'fas fa-book bg-blue-100 text-primary';
  };

  if (isLoading) {
    return (
      <div className="bg-white rounded-lg shadow p-5">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-semibold text-gray-800">Recent Classes</h3>
          <Link href="/classes">
            <a className="text-primary text-sm hover:underline">View All</a>
          </Link>
        </div>
        <div className="space-y-3">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="flex items-center p-2 rounded animate-pulse">
              <div className="p-2 rounded-lg bg-gray-200 h-8 w-8"></div>
              <div className="ml-3 w-full">
                <div className="h-4 bg-gray-200 rounded mb-2 w-3/4"></div>
                <div className="h-3 bg-gray-200 rounded w-1/2"></div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (!data || data.length === 0) {
    return (
      <div className="bg-white rounded-lg shadow p-5">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-semibold text-gray-800">Recent Classes</h3>
          <Link href="/classes">
            <a className="text-primary text-sm hover:underline">View All</a>
          </Link>
        </div>
        <div className="p-4 text-center text-gray-500">
          <p>No classes with attendance recorded today</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow p-5">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-lg font-semibold text-gray-800">Recent Classes</h3>
        <Link href="/classes">
          <a className="text-primary text-sm hover:underline">View All</a>
        </Link>
      </div>
      <div className="space-y-3">
        {data.map((classItem) => (
          <Link key={classItem.id} href={`/attendance?classId=${classItem.id}`}>
            <a className="flex items-center p-2 rounded hover:bg-gray-50 transition cursor-pointer">
              <div className={`p-2 rounded-lg ${getIconClass(classItem.name)}`}>
                <i className={getIconClass(classItem.name).split(' ')[0]}></i>
              </div>
              <div className="ml-3">
                <p className="text-sm font-medium text-gray-800">{classItem.name}</p>
                <p className="text-xs text-gray-500">
                  Today • {classItem.present}/{classItem.total} present
                </p>
              </div>
              <i className="fas fa-chevron-right ml-auto text-gray-400"></i>
            </a>
          </Link>
        ))}
      </div>
    </div>
  );
}
