import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { StatusBadge } from "@/components/ui/status-badge";
import { Button } from "@/components/ui/button";
import { TakeAttendanceModal } from "@/components/attendance/TakeAttendanceModal";
import { Dialog } from "@/components/ui/dialog";

interface Student {
  id: number;
  studentId: string;
  name: string;
  email: string | null;
  classId: number;
}

interface Class {
  id: number;
  name: string;
  grade: string;
  section: string;
  teacherId: number;
}

interface Attendance {
  id: number;
  studentId: number;
  classId: number;
  date: string;
  status: string;
  note: string | null;
  recordedBy: number;
}

interface AttendanceWithStudent extends Attendance {
  student: Student;
  class: Class;
}

export function AttendanceTable() {
  const [page, setPage] = useState(1);
  const [showModal, setShowModal] = useState(false);
  const [showStudentDetails, setShowStudentDetails] = useState<number | null>(null);
  const pageSize = 5;

  const { data, isLoading } = useQuery<AttendanceWithStudent[]>({
    queryKey: ['/api/attendance'],
    queryFn: async () => {
      const [attendancesRes, studentsRes, classesRes] = await Promise.all([
        fetch('/api/attendance'),
        fetch('/api/students'),
        fetch('/api/classes')
      ]);
      
      if (!attendancesRes.ok || !studentsRes.ok || !classesRes.ok) {
        throw new Error('Failed to fetch data');
      }
      
      const [attendances, students, classes] = await Promise.all([
        attendancesRes.json(),
        studentsRes.json(),
        classesRes.json()
      ]);
      
      return attendances.map((attendance: Attendance) => ({
        ...attendance,
        student: students.find((s: Student) => s.id === attendance.studentId),
        class: classes.find((c: Class) => c.id === attendance.classId)
      }));
    }
  });

  if (isLoading) {
    return (
      <div className="bg-white rounded-lg shadow overflow-hidden mb-6">
        <div className="p-5 border-b">
          <div className="animate-pulse flex justify-between">
            <div className="h-6 bg-gray-200 rounded w-1/4"></div>
            <div className="h-6 bg-gray-200 rounded w-1/4"></div>
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-gray-50">
                <th className="text-left py-3 px-4 text-xs font-medium text-gray-500 uppercase">Student</th>
                <th className="text-left py-3 px-4 text-xs font-medium text-gray-500 uppercase">ID</th>
                <th className="text-left py-3 px-4 text-xs font-medium text-gray-500 uppercase">Class</th>
                <th className="text-left py-3 px-4 text-xs font-medium text-gray-500 uppercase">Status</th>
                <th className="text-left py-3 px-4 text-xs font-medium text-gray-500 uppercase">Time</th>
                <th className="text-left py-3 px-4 text-xs font-medium text-gray-500 uppercase">Actions</th>
              </tr>
            </thead>
            <tbody>
              {[1, 2, 3, 4, 5].map((i) => (
                <tr key={i} className="border-b">
                  <td className="py-3 px-4">
                    <div className="flex items-center">
                      <div className="w-8 h-8 rounded-full bg-gray-200"></div>
                      <div className="ml-3 w-full">
                        <div className="h-4 bg-gray-200 rounded mb-1 w-3/4"></div>
                        <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                      </div>
                    </div>
                  </td>
                  <td className="py-3 px-4"><div className="h-4 bg-gray-200 rounded w-20"></div></td>
                  <td className="py-3 px-4"><div className="h-4 bg-gray-200 rounded w-24"></div></td>
                  <td className="py-3 px-4"><div className="h-4 bg-gray-200 rounded w-16"></div></td>
                  <td className="py-3 px-4"><div className="h-4 bg-gray-200 rounded w-16"></div></td>
                  <td className="py-3 px-4"><div className="h-4 bg-gray-200 rounded w-12"></div></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    );
  }

  if (!data || data.length === 0) {
    return (
      <div className="bg-white rounded-lg shadow overflow-hidden mb-6">
        <div className="p-5 border-b flex flex-col sm:flex-row sm:items-center sm:justify-between">
          <h3 className="text-lg font-semibold text-gray-800">Today's Attendance</h3>
          <div className="mt-3 sm:mt-0">
            <Button onClick={() => setShowModal(true)}>
              <i className="fas fa-plus mr-2"></i>
              Take Attendance
            </Button>
          </div>
        </div>
        <div className="p-8 text-center">
          <p className="text-gray-500">No attendance records for today</p>
          <Button className="mt-4" onClick={() => setShowModal(true)}>
            <i className="fas fa-plus mr-2"></i>
            Take Attendance
          </Button>
        </div>
        <TakeAttendanceModal open={showModal} onOpenChange={setShowModal} />
      </div>
    );
  }

  // Paginate the data
  const totalPages = Math.ceil(data.length / pageSize);
  const paginatedData = data.slice((page - 1) * pageSize, page * pageSize);

  // Format the time from ISO string
  const formatTime = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
  };

  const selectedStudent = showStudentDetails 
    ? data.find(item => item.student.id === showStudentDetails)?.student 
    : null;

  return (
    <div className="bg-white rounded-lg shadow overflow-hidden mb-6">
      <div className="p-5 border-b flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <h3 className="text-lg font-semibold text-gray-800">Today's Attendance</h3>
        <div className="mt-3 sm:mt-0 flex flex-wrap gap-2">
          <Button variant="outline" size="sm">
            <i className="fas fa-filter text-gray-500 mr-1"></i>
            Filter
          </Button>
          <Button variant="outline" size="sm">
            <i className="fas fa-file-export text-gray-500 mr-1"></i>
            Export
          </Button>
          <Button variant="outline" size="sm">
            <i className="fas fa-print text-gray-500 mr-1"></i>
            Print
          </Button>
          <Button size="sm" onClick={() => setShowModal(true)}>
            <i className="fas fa-plus mr-1"></i>
            Take
          </Button>
        </div>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="bg-gray-50">
              <th className="text-left py-3 px-4 text-xs font-medium text-gray-500 uppercase tracking-wider">Student</th>
              <th className="text-left py-3 px-4 text-xs font-medium text-gray-500 uppercase tracking-wider">ID</th>
              <th className="text-left py-3 px-4 text-xs font-medium text-gray-500 uppercase tracking-wider">Class</th>
              <th className="text-left py-3 px-4 text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
              <th className="text-left py-3 px-4 text-xs font-medium text-gray-500 uppercase tracking-wider">Time</th>
              <th className="text-left py-3 px-4 text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {paginatedData.map((item) => (
              <tr key={item.id} className="hover:bg-gray-50">
                <td className="py-3 px-4">
                  <div className="flex items-center">
                    <div className="w-8 h-8 rounded-full bg-gray-300 flex items-center justify-center mr-3">
                      <span className="text-sm font-medium text-gray-600">
                        {item.student.name.charAt(0)}
                      </span>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-gray-800">{item.student.name}</p>
                      <p className="text-xs text-gray-500">{item.student.email || ''}</p>
                    </div>
                  </div>
                </td>
                <td className="py-3 px-4 text-sm text-gray-600">{item.student.studentId}</td>
                <td className="py-3 px-4 text-sm text-gray-600">{item.class.grade}-{item.class.section}</td>
                <td className="py-3 px-4">
                  <StatusBadge status={item.status} />
                </td>
                <td className="py-3 px-4 text-sm text-gray-600">
                  {item.status === 'absent' ? '--' : formatTime(item.date)}
                </td>
                <td className="py-3 px-4 text-sm">
                  <div className="flex space-x-2">
                    <button className="text-gray-500 hover:text-primary">
                      <i className="fas fa-edit"></i>
                    </button>
                    <button 
                      className="text-gray-500 hover:text-primary"
                      onClick={() => setShowStudentDetails(item.student.id)}
                    >
                      <i className="fas fa-info-circle"></i>
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="px-4 py-3 border-t flex flex-col sm:flex-row items-center justify-between">
        <p className="text-sm text-gray-600 mb-2 sm:mb-0">
          Showing {paginatedData.length} of {data.length} students
        </p>
        <div className="flex items-center">
          <Button
            variant="outline"
            size="sm"
            className="mr-2"
            disabled={page === 1}
            onClick={() => setPage(page - 1)}
          >
            <i className="fas fa-chevron-left"></i>
          </Button>
          <span className="text-sm text-gray-600">Page {page} of {totalPages}</span>
          <Button
            variant="outline"
            size="sm"
            className="ml-2"
            disabled={page === totalPages}
            onClick={() => setPage(page + 1)}
          >
            <i className="fas fa-chevron-right"></i>
          </Button>
        </div>
      </div>

      <TakeAttendanceModal open={showModal} onOpenChange={setShowModal} />

      <Dialog open={!!showStudentDetails} onOpenChange={() => setShowStudentDetails(null)}>
        <div className="p-6">
          {selectedStudent && (
            <div>
              <h3 className="text-lg font-semibold mb-4">Student Details</h3>
              <div className="space-y-3">
                <div>
                  <p className="text-sm text-gray-500">Name</p>
                  <p className="font-medium">{selectedStudent.name}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">ID</p>
                  <p className="font-medium">{selectedStudent.studentId}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Email</p>
                  <p className="font-medium">{selectedStudent.email || 'N/A'}</p>
                </div>
              </div>
              <div className="mt-6 flex justify-end">
                <Button 
                  variant="outline" 
                  onClick={() => setShowStudentDetails(null)}
                >
                  Close
                </Button>
              </div>
            </div>
          )}
        </div>
      </Dialog>
    </div>
  );
}
