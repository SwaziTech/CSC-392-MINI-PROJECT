import { useQuery } from "@tanstack/react-query";

interface StatsData {
  total: number;
  present: number;
  absent: number;
  late: number;
  presentPercentage: string;
  absentPercentage: string;
  latePercentage: string;
}

export function StatsCards() {
  const { data, isLoading } = useQuery<StatsData>({
    queryKey: ['/api/stats/today']
  });

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        {[1, 2, 3].map((i) => (
          <div key={i} className="bg-white rounded-lg shadow p-5 animate-pulse">
            <div className="flex items-center">
              <div className="p-3 rounded-full bg-gray-200 mr-4 h-12 w-12"></div>
              <div className="w-full">
                <div className="h-4 bg-gray-200 rounded mb-2 w-1/2"></div>
                <div className="h-6 bg-gray-200 rounded mb-2 w-1/4"></div>
                <div className="h-3 bg-gray-200 rounded w-1/3"></div>
              </div>
            </div>
          </div>
        ))}
      </div>
    );
  }

  if (!data) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div className="bg-white rounded-lg shadow p-5">
          <p className="text-gray-500 text-center">No attendance data available for today</p>
        </div>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
      <div className="bg-white rounded-lg shadow p-5">
        <div className="flex items-center">
          <div className="p-3 rounded-full bg-blue-100 text-primary mr-4">
            <i className="fas fa-user-check text-xl"></i>
          </div>
          <div>
            <p className="text-gray-500 text-sm">Present Today</p>
            <p className="text-2xl font-semibold text-gray-800">{data.presentPercentage}%</p>
            <p className="text-xs text-green-600 mt-1">
              <i className="fas fa-users"></i> {data.present} of {data.total} students
            </p>
          </div>
        </div>
      </div>
      <div className="bg-white rounded-lg shadow p-5">
        <div className="flex items-center">
          <div className="p-3 rounded-full bg-red-100 text-red-600 mr-4">
            <i className="fas fa-user-times text-xl"></i>
          </div>
          <div>
            <p className="text-gray-500 text-sm">Absent Today</p>
            <p className="text-2xl font-semibold text-gray-800">{data.absentPercentage}%</p>
            <p className="text-xs text-red-600 mt-1">
              <i className="fas fa-users"></i> {data.absent} of {data.total} students
            </p>
          </div>
        </div>
      </div>
      <div className="bg-white rounded-lg shadow p-5">
        <div className="flex items-center">
          <div className="p-3 rounded-full bg-yellow-100 text-yellow-600 mr-4">
            <i className="fas fa-clock text-xl"></i>
          </div>
          <div>
            <p className="text-gray-500 text-sm">Late Today</p>
            <p className="text-2xl font-semibold text-gray-800">{data.latePercentage}%</p>
            <p className="text-xs text-yellow-600 mt-1">
              <i className="fas fa-users"></i> {data.late} of {data.total} students
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
