import { useQuery } from "@tanstack/react-query";
import { StatusBadge } from "@/components/ui/status-badge";
import { useState } from "react";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

interface AbsenceNote {
  id: number;
  studentId: number;
  date: string;
  note: string;
  status: string;
  submittedBy: number;
  student?: {
    id: number;
    name: string;
    studentId: string;
    classId: number;
  };
  class?: {
    grade: string;
    section: string;
  };
}

export function AbsenceNotes() {
  const { toast } = useToast();
  const [updating, setUpdating] = useState<number | null>(null);

  const { data, isLoading, refetch } = useQuery<AbsenceNote[]>({
    queryKey: ['/api/absence-notes'],
    queryFn: async () => {
      const [notesRes, studentsRes, classesRes] = await Promise.all([
        fetch('/api/absence-notes'),
        fetch('/api/students'),
        fetch('/api/classes')
      ]);
      
      if (!notesRes.ok || !studentsRes.ok || !classesRes.ok) {
        throw new Error('Failed to fetch data');
      }
      
      const [notes, students, classes] = await Promise.all([
        notesRes.json(),
        studentsRes.json(),
        classesRes.json()
      ]);
      
      return notes.map((note: AbsenceNote) => {
        const student = students.find((s: any) => s.id === note.studentId);
        const classItem = student ? classes.find((c: any) => c.id === student.classId) : null;
        
        return {
          ...note,
          student,
          class: classItem
        };
      });
    }
  });

  const handleApprove = async (id: number) => {
    try {
      setUpdating(id);
      await apiRequest('PUT', `/api/absence-notes/${id}`, { status: 'approved' });
      toast({
        title: "Success",
        description: "Absence note approved",
      });
      refetch();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to approve absence note",
        variant: "destructive",
      });
    } finally {
      setUpdating(null);
    }
  };

  const handleDecline = async (id: number) => {
    try {
      setUpdating(id);
      await apiRequest('PUT', `/api/absence-notes/${id}`, { status: 'declined' });
      toast({
        title: "Success",
        description: "Absence note declined",
      });
      refetch();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to decline absence note",
        variant: "destructive",
      });
    } finally {
      setUpdating(null);
    }
  };

  if (isLoading) {
    return (
      <div className="bg-white rounded-lg shadow p-5">
        <h3 className="text-lg font-semibold text-gray-800 mb-4">Recent Absence Notes</h3>
        <div className="space-y-3">
          {[1, 2].map((i) => (
            <div key={i} className="border border-gray-200 rounded-lg p-3 animate-pulse">
              <div className="flex justify-between">
                <div className="w-1/3">
                  <div className="h-4 bg-gray-200 rounded mb-2"></div>
                  <div className="h-3 bg-gray-200 rounded w-3/4"></div>
                </div>
                <div className="h-5 w-16 bg-gray-200 rounded-full"></div>
              </div>
              <div className="h-4 bg-gray-200 rounded mt-2 w-full"></div>
              <div className="flex justify-end mt-2">
                <div className="h-6 w-16 bg-gray-200 rounded mr-2"></div>
                <div className="h-6 w-16 bg-gray-200 rounded"></div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  const filteredNotes = data?.filter(note => 
    note.student && note.class
  ).slice(0, 3) || [];

  if (filteredNotes.length === 0) {
    return (
      <div className="bg-white rounded-lg shadow p-5">
        <h3 className="text-lg font-semibold text-gray-800 mb-4">Recent Absence Notes</h3>
        <p className="text-gray-500 text-center py-4">No absence notes available</p>
      </div>
    );
  }

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
  };

  return (
    <div className="bg-white rounded-lg shadow p-5">
      <h3 className="text-lg font-semibold text-gray-800 mb-4">Recent Absence Notes</h3>
      <div className="space-y-3">
        {filteredNotes.map((note) => (
          <div key={note.id} className="border border-gray-200 rounded-lg p-3">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-sm font-medium text-gray-800">{note.student?.name}</p>
                <p className="text-xs text-gray-500">
                  Grade {note.class?.grade}-{note.class?.section} • {note.student?.studentId}
                </p>
              </div>
              <StatusBadge status={note.status} className="text-xs" />
            </div>
            <p className="text-sm text-gray-600 mt-2">
              {note.note} ({formatDate(note.date)})
            </p>
            {note.status === 'pending' && (
              <div className="flex justify-end mt-2">
                <Button
                  size="sm"
                  variant="success"
                  className="mr-2 bg-green-500 hover:bg-green-600 text-white"
                  onClick={() => handleApprove(note.id)}
                  disabled={updating === note.id}
                >
                  {updating === note.id ? (
                    <span className="animate-spin mr-1">↻</span>
                  ) : (
                    "Approve"
                  )}
                </Button>
                <Button
                  size="sm"
                  variant="destructive"
                  onClick={() => handleDecline(note.id)}
                  disabled={updating === note.id}
                >
                  Decline
                </Button>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
