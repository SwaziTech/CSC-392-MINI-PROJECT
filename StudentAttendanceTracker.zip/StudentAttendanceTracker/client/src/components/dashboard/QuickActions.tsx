import { Link } from "wouter";

export function QuickActions() {
  const actions = [
    {
      icon: "fas fa-user-plus",
      label: "Add Student",
      link: "/students/add",
    },
    {
      icon: "fas fa-clipboard-list",
      label: "New Report",
      link: "/reports",
    },
    {
      icon: "fas fa-users-cog",
      label: "Manage Class",
      link: "/classes",
    },
    {
      icon: "fas fa-bell",
      label: "Notifications",
      link: "/notifications",
    },
  ];

  return (
    <div className="bg-white rounded-lg shadow p-5">
      <h3 className="text-lg font-semibold text-gray-800 mb-4">Quick Actions</h3>
      <div className="grid grid-cols-2 gap-3">
        {actions.map((action) => (
          <Link key={action.label} href={action.link}>
            <a className="p-3 border border-gray-200 rounded-lg hover:border-primary hover:bg-blue-50 transition flex flex-col items-center justify-center">
              <i className={`${action.icon} text-primary text-lg mb-2`}></i>
              <span className="text-sm text-gray-700">{action.label}</span>
            </a>
          </Link>
        ))}
      </div>
    </div>
  );
}
