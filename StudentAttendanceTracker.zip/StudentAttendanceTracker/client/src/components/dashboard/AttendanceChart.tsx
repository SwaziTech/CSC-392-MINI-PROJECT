import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer 
} from "recharts";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface TrendDataPoint {
  date: string;
  presentPercentage: string;
  absentPercentage: string;
  latePercentage: string;
}

export function AttendanceChart() {
  const [days, setDays] = useState("7");
  
  const { data, isLoading } = useQuery<TrendDataPoint[]>({
    queryKey: ['/api/stats/trends', days],
    queryFn: async () => {
      const res = await fetch(`/api/stats/trends?days=${days}`);
      if (!res.ok) throw new Error("Failed to fetch attendance trends");
      return res.json();
    }
  });

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  };

  const handleDaysChange = (value: string) => {
    setDays(value);
  };

  return (
    <div className="bg-white rounded-lg shadow p-5 lg:col-span-2">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-lg font-semibold text-gray-800">Attendance Trends</h3>
        <Select value={days} onValueChange={handleDaysChange}>
          <SelectTrigger className="w-[140px]">
            <SelectValue placeholder="Select period" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="7">Last 7 days</SelectItem>
            <SelectItem value="14">Last 14 days</SelectItem>
            <SelectItem value="30">Last 30 days</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <div className="h-64 relative">
        {isLoading ? (
          <div className="h-full w-full bg-gray-50 rounded flex items-center justify-center">
            <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
          </div>
        ) : data && data.length > 0 ? (
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={data} margin={{ top: 5, right: 20, left: 0, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" tickFormatter={formatDate} />
              <YAxis domain={[0, 100]} />
              <Tooltip 
                formatter={(value) => [`${value}%`, '']}
                labelFormatter={(label) => formatDate(label as string)}
              />
              <Legend />
              <Line 
                type="monotone" 
                dataKey="presentPercentage" 
                name="Present" 
                stroke="#3b82f6" 
                activeDot={{ r: 8 }} 
              />
              <Line 
                type="monotone" 
                dataKey="absentPercentage" 
                name="Absent" 
                stroke="#ef4444" 
              />
              <Line 
                type="monotone" 
                dataKey="latePercentage" 
                name="Late" 
                stroke="#f59e0b" 
              />
            </LineChart>
          </ResponsiveContainer>
        ) : (
          <div className="h-full w-full bg-gray-50 rounded flex items-center justify-center">
            <p className="text-gray-500 text-sm">No attendance data available</p>
          </div>
        )}
      </div>
    </div>
  );
}
