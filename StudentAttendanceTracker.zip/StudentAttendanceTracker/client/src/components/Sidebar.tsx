import { Link, useLocation } from "wouter";
import { User } from "@shared/schema";

interface SidebarProps {
  user: Omit<User, "password">;
  onLogout: () => void;
}

export function Sidebar({ user, onLogout }: SidebarProps) {
  const [location] = useLocation();

  const menuItems = [
    { path: "/", icon: "fas fa-tachometer-alt", label: "Dashboard" },
    { path: "/students", icon: "fas fa-user-graduate", label: "Students" },
    { path: "/classes", icon: "fas fa-users", label: "Classes" },
    { path: "/attendance", icon: "fas fa-clipboard-check", label: "Attendance" },
    { path: "/reports", icon: "fas fa-chart-bar", label: "Reports" },
  ];

  return (
    <aside className="w-64 bg-white h-full shadow-md hidden lg:block">
      <div className="px-6 py-4 border-b">
        <h1 className="text-xl font-semibold text-gray-800">Attendance System</h1>
      </div>
      <div className="py-2">
        {menuItems.map((item) => (
          <Link key={item.path} href={item.path}>
            <a
              className={`px-6 py-3 flex items-center ${
                location === item.path
                  ? "bg-blue-50 text-primary border-l-3 border-primary"
                  : "text-gray-700 hover:bg-gray-100"
              } cursor-pointer`}
              data-active={location === item.path}
            >
              <i className={`${item.icon} w-5 text-center`}></i>
              <span className="ml-3">{item.label}</span>
            </a>
          </Link>
        ))}
      </div>
      <div className="absolute bottom-0 w-64 border-t">
        <div className="px-6 py-4 flex items-center">
          <div className="w-8 h-8 rounded-full bg-gray-300 flex items-center justify-center">
            <span className="text-sm font-medium text-gray-600">
              {user.name.charAt(0)}
            </span>
          </div>
          <div className="ml-2">
            <p className="text-sm font-medium text-gray-700">{user.name}</p>
            <p className="text-xs text-gray-500">{user.role}</p>
          </div>
          <button
            onClick={onLogout}
            className="ml-auto text-gray-500 hover:text-gray-700 cursor-pointer"
          >
            <i className="fas fa-sign-out-alt"></i>
          </button>
        </div>
      </div>
    </aside>
  );
}
