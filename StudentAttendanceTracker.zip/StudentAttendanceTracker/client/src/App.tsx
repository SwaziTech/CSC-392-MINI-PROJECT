import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Login from "@/pages/login";
import Register from "@/pages/register";
import Dashboard from "@/pages/dashboard";
import StudentsIndex from "@/pages/students/index";
import AddStudent from "@/pages/students/add";
import ClassesIndex from "@/pages/classes/index";
import AddClass from "@/pages/classes/add";
import AttendanceIndex from "@/pages/attendance/index";
import ReportsIndex from "@/pages/reports/index";
import MainLayout from "@/layouts/MainLayout";
import { AuthProvider } from "@/hooks/useAuth";

function Router() {
  return (
    <Switch>
      <Route path="/login" component={Login} />
      <Route path="/register" component={Register} />
      <Route path="/">
        <MainLayout>
          <Dashboard />
        </MainLayout>
      </Route>
      <Route path="/students">
        <MainLayout>
          <StudentsIndex />
        </MainLayout>
      </Route>
      <Route path="/students/add">
        <MainLayout>
          <AddStudent />
        </MainLayout>
      </Route>
      <Route path="/classes">
        <MainLayout>
          <ClassesIndex />
        </MainLayout>
      </Route>
      <Route path="/classes/add">
        <MainLayout>
          <AddClass />
        </MainLayout>
      </Route>
      <Route path="/attendance">
        <MainLayout>
          <AttendanceIndex />
        </MainLayout>
      </Route>
      <Route path="/reports">
        <MainLayout>
          <ReportsIndex />
        </MainLayout>
      </Route>
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <AuthProvider>
          <Toaster />
          <Router />
        </AuthProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
