import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  BarChart, 
  Bar, 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from "recharts";
import { Class, Student, Attendance } from "@shared/schema";

export default function ReportsIndex() {
  const [reportType, setReportType] = useState<string>("daily");
  const [selectedClass, setSelectedClass] = useState<string>("");
  const [startDate, setStartDate] = useState<string>(() => {
    const date = new Date();
    date.setDate(date.getDate() - 7);
    return date.toISOString().split('T')[0];
  });
  const [endDate, setEndDate] = useState<string>(() => {
    const today = new Date();
    return today.toISOString().split('T')[0];
  });

  // Fetch classes
  const { data: classes } = useQuery<Class[]>({
    queryKey: ['/api/classes'],
  });

  // Fetch attendance data
  const { data: attendances, isLoading: attendancesLoading } = useQuery<Attendance[]>({
    queryKey: ['/api/attendance', startDate, endDate, selectedClass],
    queryFn: async () => {
      let url = `/api/stats/trends?days=7`; // Using the trends endpoint for the stats
      const res = await fetch(url);
      if (!res.ok) throw new Error('Failed to fetch attendance data');
      return res.json();
    },
  });

  // Helper function to generate reports data
  const generateReportData = () => {
    if (!attendances) return [];

    if (reportType === "daily") {
      return attendances;
    } else if (reportType === "weekly" || reportType === "monthly") {
      // For simplicity, we're using the same data for weekly/monthly views
      return attendances;
    }

    return attendances;
  };

  const reportData = generateReportData();

  // Colors for pie chart
  const COLORS = ['#3b82f6', '#ef4444', '#f59e0b'];

  // Calculate attendance summary data for pie chart
  const calculateSummaryData = () => {
    if (!attendances || attendances.length === 0) return [];

    // Calculate average percentages
    const totalDays = attendances.length;
    const avgPresent = attendances.reduce((sum, day) => sum + parseFloat(day.presentPercentage), 0) / totalDays;
    const avgAbsent = attendances.reduce((sum, day) => sum + parseFloat(day.absentPercentage), 0) / totalDays;
    const avgLate = attendances.reduce((sum, day) => sum + parseFloat(day.latePercentage), 0) / totalDays;

    return [
      { name: 'Present', value: avgPresent },
      { name: 'Absent', value: avgAbsent },
      { name: 'Late', value: avgLate }
    ];
  };

  const summaryData = calculateSummaryData();

  // Handler for exporting data
  const handleExport = (format: 'csv' | 'pdf') => {
    if (!reportData.length) return;

    if (format === 'csv') {
      // Simple CSV export
      const headers = Object.keys(reportData[0]).join(',');
      const rows = reportData.map(row => Object.values(row).join(',')).join('\n');
      const csv = `${headers}\n${rows}`;
      
      const blob = new Blob([csv], { type: 'text/csv' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `attendance_report_${reportType}_${new Date().toISOString().split('T')[0]}.csv`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } else if (format === 'pdf') {
      // In a real app, you would use a library like jsPDF
      alert("PDF export would be implemented with a PDF generation library in a real application");
    }
  };

  // Format date for display
  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  };

  return (
    <>
      <div className="mb-6">
        <h2 className="text-2xl font-semibold text-gray-800">Attendance Reports</h2>
        <p className="text-sm text-gray-600 mt-1">
          Generate and export attendance reports
        </p>
      </div>

      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Report Options</CardTitle>
          <CardDescription>Configure the attendance report parameters</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Report Type</label>
              <Select value={reportType} onValueChange={setReportType}>
                <SelectTrigger>
                  <SelectValue placeholder="Select report type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="daily">Daily</SelectItem>
                  <SelectItem value="weekly">Weekly</SelectItem>
                  <SelectItem value="monthly">Monthly</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Class</label>
              <Select value={selectedClass} onValueChange={setSelectedClass}>
                <SelectTrigger>
                  <SelectValue placeholder="All Classes" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">All Classes</SelectItem>
                  {classes && classes.map((cls) => (
                    <SelectItem key={cls.id} value={cls.id.toString()}>
                      {cls.grade}-{cls.section}: {cls.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Start Date</label>
              <Input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                max={endDate}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">End Date</label>
              <Input
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                min={startDate}
                max={new Date().toISOString().split('T')[0]}
              />
            </div>
          </div>
          <div className="mt-4 flex justify-end space-x-2">
            <Button 
              variant="outline" 
              onClick={() => handleExport('csv')}
              disabled={!reportData.length}
            >
              <i className="fas fa-file-csv mr-2"></i>
              Export CSV
            </Button>
            <Button 
              variant="outline" 
              onClick={() => handleExport('pdf')}
              disabled={!reportData.length}
            >
              <i className="fas fa-file-pdf mr-2"></i>
              Export PDF
            </Button>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Attendance Trends</CardTitle>
            <CardDescription>
              {reportType === "daily" ? "Daily" : reportType === "weekly" ? "Weekly" : "Monthly"} attendance trend
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              {attendancesLoading ? (
                <div className="h-full flex items-center justify-center">
                  <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
                </div>
              ) : reportData.length > 0 ? (
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={reportData} margin={{ top: 5, right: 20, left: 0, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" tickFormatter={formatDate} />
                    <YAxis domain={[0, 100]} />
                    <Tooltip 
                      formatter={(value) => [`${value}%`, '']} 
                      labelFormatter={(label) => typeof label === 'string' ? formatDate(label) : label}
                    />
                    <Legend />
                    <Line type="monotone" dataKey="presentPercentage" name="Present" stroke="#3b82f6" activeDot={{ r: 8 }} />
                    <Line type="monotone" dataKey="absentPercentage" name="Absent" stroke="#ef4444" />
                    <Line type="monotone" dataKey="latePercentage" name="Late" stroke="#f59e0b" />
                  </LineChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-full flex items-center justify-center">
                  <p className="text-gray-500">No data available for the selected period</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Attendance Summary</CardTitle>
            <CardDescription>Average attendance breakdown</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              {attendancesLoading ? (
                <div className="h-full flex items-center justify-center">
                  <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
                </div>
              ) : summaryData.length > 0 ? (
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={summaryData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(1)}%`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {summaryData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value) => [`${parseFloat(value as string).toFixed(1)}%`, '']} />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-full flex items-center justify-center">
                  <p className="text-gray-500">No data available for the selected period</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Attendance Statistics</CardTitle>
          <CardDescription>Detailed attendance metrics</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-80">
            {attendancesLoading ? (
              <div className="h-full flex items-center justify-center">
                <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
              </div>
            ) : reportData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={reportData} margin={{ top: 5, right: 20, left: 0, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" tickFormatter={formatDate} />
                  <YAxis />
                  <Tooltip 
                    formatter={(value, name) => {
                      if (name === "present" || name === "absent" || name === "late") {
                        return [value, name.charAt(0).toUpperCase() + name.slice(1)];
                      }
                      return [value, name];
                    }}
                    labelFormatter={(label) => typeof label === 'string' ? formatDate(label) : label}
                  />
                  <Legend />
                  <Bar dataKey="present" name="Present" fill="#3b82f6" />
                  <Bar dataKey="absent" name="Absent" fill="#ef4444" />
                  <Bar dataKey="late" name="Late" fill="#f59e0b" />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex items-center justify-center">
                <p className="text-gray-500">No data available for the selected period</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </>
  );
}
