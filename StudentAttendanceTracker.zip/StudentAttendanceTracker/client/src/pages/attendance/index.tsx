import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { StatusBadge } from "@/components/ui/status-badge";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Attendance, Student, Class } from "@shared/schema";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { TakeAttendanceModal } from "@/components/attendance/TakeAttendanceModal";

export default function AttendanceIndex() {
  const [, setLocation] = useLocation();
  const [selectedDate, setSelectedDate] = useState<string>(() => {
    const today = new Date();
    return today.toISOString().split('T')[0];
  });
  const [selectedClass, setSelectedClass] = useState<string>("");
  const [searchQuery, setSearchQuery] = useState("");
  const [showModal, setShowModal] = useState(false);

  // Parse URL params for classId
  const [location] = useLocation();
  useEffect(() => {
    const params = new URLSearchParams(location.split('?')[1]);
    const classId = params.get('classId');
    if (classId) setSelectedClass(classId);
  }, [location]);

  // Fetch classes for the dropdown
  const { data: classes, isLoading: classesLoading } = useQuery<Class[]>({
    queryKey: ['/api/classes'],
  });

  // Fetch attendance data based on selected date and class
  const { data: attendances, isLoading: attendancesLoading } = useQuery<Attendance[]>({
    queryKey: ['/api/attendance', selectedDate, selectedClass],
    queryFn: async () => {
      let url = `/api/attendance?date=${selectedDate}`;
      if (selectedClass) {
        url += `&classId=${selectedClass}`;
      }
      const res = await fetch(url);
      if (!res.ok) throw new Error('Failed to fetch attendance records');
      return res.json();
    },
    enabled: !!selectedDate,
  });

  // Fetch students
  const { data: students } = useQuery<Student[]>({
    queryKey: ['/api/students'],
  });

  // Join attendance data with student data
  const attendanceRecords = attendances?.map(attendance => {
    const student = students?.find(s => s.id === attendance.studentId);
    return {
      ...attendance,
      student,
    };
  });

  // Filter attendance records based on search query
  const filteredRecords = attendanceRecords?.filter(record => 
    record.student && (
      record.student.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      record.student.studentId.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (record.student.email && record.student.email.toLowerCase().includes(searchQuery.toLowerCase()))
    )
  );

  // Format date for display
  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  return (
    <>
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between mb-6">
        <div>
          <h2 className="text-2xl font-semibold text-gray-800">Attendance</h2>
          <p className="text-sm text-gray-600 mt-1">
            Manage and view student attendance records
          </p>
        </div>
        <div className="mt-4 lg:mt-0 flex flex-col sm:flex-row gap-2">
          <Button onClick={() => setShowModal(true)}>
            <i className="fas fa-plus mr-2"></i>
            <span>Take Attendance</span>
          </Button>
        </div>
      </div>

      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Attendance Filters</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Date</label>
              <Input
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                max={new Date().toISOString().split('T')[0]}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Class</label>
              <Select value={selectedClass} onValueChange={setSelectedClass}>
                <SelectTrigger>
                  <SelectValue placeholder="All Classes" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">All Classes</SelectItem>
                  {classesLoading ? (
                    <SelectItem value="" disabled>Loading classes...</SelectItem>
                  ) : classes && classes.length > 0 ? (
                    classes.map((cls) => (
                      <SelectItem key={cls.id} value={cls.id.toString()}>
                        {cls.grade}-{cls.section}: {cls.name}
                      </SelectItem>
                    ))
                  ) : (
                    <SelectItem value="" disabled>No classes available</SelectItem>
                  )}
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Search</label>
              <div className="relative">
                <Input
                  type="text"
                  className="pl-9"
                  placeholder="Search students..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
                <i className="fas fa-search absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"></i>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>
            Attendance Records for {formatDate(selectedDate)}
            {selectedClass && classes && (
              <>
                {" - "}
                {(() => {
                  const cls = classes.find(c => c.id.toString() === selectedClass);
                  return cls ? `${cls.grade}-${cls.section}: ${cls.name}` : "";
                })()}
              </>
            )}
          </CardTitle>
        </CardHeader>
        <CardContent>
          {attendancesLoading ? (
            <div className="flex justify-center items-center py-8">
              <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
            </div>
          ) : filteredRecords && filteredRecords.length > 0 ? (
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Student</TableHead>
                    <TableHead>ID</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Time</TableHead>
                    <TableHead>Note</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredRecords.map((record) => (
                    <TableRow key={record.id}>
                      <TableCell>
                        <div className="flex items-center">
                          <div className="w-8 h-8 rounded-full bg-gray-300 flex items-center justify-center mr-3">
                            <span className="text-sm font-medium text-gray-600">
                              {record.student?.name.charAt(0)}
                            </span>
                          </div>
                          <span className="font-medium">{record.student?.name}</span>
                        </div>
                      </TableCell>
                      <TableCell>{record.student?.studentId}</TableCell>
                      <TableCell>
                        <StatusBadge status={record.status} />
                      </TableCell>
                      <TableCell>
                        {record.status === 'absent' ? 
                          '--' : 
                          new Date(record.date).toLocaleTimeString('en-US', { 
                            hour: '2-digit', 
                            minute: '2-digit' 
                          })
                        }
                      </TableCell>
                      <TableCell>
                        {record.note ? (
                          <div title={record.note} className="max-w-[200px] truncate">
                            {record.note}
                          </div>
                        ) : (
                          <span className="text-gray-400">No note</span>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          ) : (
            <div className="text-center py-8">
              <p className="text-gray-500">No attendance records found for the selected date and class</p>
              <Button 
                className="mt-4" 
                onClick={() => setShowModal(true)}
              >
                <i className="fas fa-plus mr-2"></i>
                Take Attendance
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      <TakeAttendanceModal 
        open={showModal} 
        onOpenChange={setShowModal} 
      />
    </>
  );
}
