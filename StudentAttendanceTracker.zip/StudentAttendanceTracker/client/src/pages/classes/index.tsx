import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Class, User } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

export default function ClassesIndex() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState("");
  const [deleteClass, setDeleteClass] = useState<number | null>(null);

  // Fetch classes data
  const { data: classes, isLoading: classesLoading } = useQuery<Class[]>({
    queryKey: ['/api/classes'],
  });

  // Fetch teachers for display
  const { data: users } = useQuery<User[]>({
    queryKey: ['/api/users'],
    queryFn: async () => {
      // Since we don't have a dedicated endpoint for users, we'll just use the current user
      try {
        const res = await fetch('/api/auth/me');
        if (!res.ok) return [];
        const user = await res.json();
        return [user];
      } catch (error) {
        return [];
      }
    }
  });

  // Filter classes based on search query
  const filteredClasses = classes?.filter(cls => 
    cls.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    cls.grade.toLowerCase().includes(searchQuery.toLowerCase()) ||
    cls.section.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Get teacher name for a class
  const getTeacherName = (teacherId: number) => {
    const teacher = users?.find(u => u.id === teacherId);
    return teacher ? teacher.name : 'Unknown Teacher';
  };

  // Handle class deletion
  const handleDeleteConfirm = async () => {
    if (!deleteClass) return;
    
    try {
      await apiRequest('DELETE', `/api/classes/${deleteClass}`, undefined);
      queryClient.invalidateQueries({ queryKey: ['/api/classes'] });
      toast({
        title: "Success",
        description: "Class deleted successfully",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to delete class. Make sure there are no students assigned to this class.",
        variant: "destructive",
      });
    } finally {
      setDeleteClass(null);
    }
  };

  return (
    <>
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between mb-6">
        <div>
          <h2 className="text-2xl font-semibold text-gray-800">Classes</h2>
          <p className="text-sm text-gray-600 mt-1">
            Manage class sections and assignments
          </p>
        </div>
        <div className="mt-4 lg:mt-0 flex flex-col sm:flex-row gap-2">
          <div className="relative">
            <Input
              type="text"
              className="pl-9 pr-4 py-2 w-full lg:w-[250px]"
              placeholder="Search classes..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
            <i className="fas fa-search absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"></i>
          </div>
          <Button onClick={() => setLocation("/classes/add")}>
            <i className="fas fa-plus mr-2"></i>
            <span>Add Class</span>
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Class List</CardTitle>
        </CardHeader>
        <CardContent>
          {classesLoading ? (
            <div className="flex justify-center items-center py-8">
              <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
            </div>
          ) : filteredClasses && filteredClasses.length > 0 ? (
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Class Name</TableHead>
                    <TableHead>Grade</TableHead>
                    <TableHead>Section</TableHead>
                    <TableHead>Teacher</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredClasses.map((cls) => (
                    <TableRow key={cls.id}>
                      <TableCell className="font-medium">{cls.name}</TableCell>
                      <TableCell>{cls.grade}</TableCell>
                      <TableCell>{cls.section}</TableCell>
                      <TableCell>{getTeacherName(cls.teacherId)}</TableCell>
                      <TableCell>
                        <div className="flex space-x-2">
                          <Button 
                            variant="ghost" 
                            size="icon"
                            onClick={() => setLocation(`/classes/edit/${cls.id}`)}
                          >
                            <i className="fas fa-edit text-blue-500"></i>
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            onClick={() => setDeleteClass(cls.id)}
                          >
                            <i className="fas fa-trash text-red-500"></i>
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          ) : (
            <div className="text-center py-8">
              <p className="text-gray-500">No classes found</p>
              {searchQuery && (
                <p className="text-sm text-gray-400 mt-2">
                  Try a different search term or{" "}
                  <Button 
                    variant="link" 
                    className="p-0 h-auto text-primary" 
                    onClick={() => setSearchQuery("")}
                  >
                    clear the search
                  </Button>
                </p>
              )}
              <Button 
                className="mt-4" 
                onClick={() => setLocation("/classes/add")}
              >
                <i className="fas fa-plus mr-2"></i>
                Add Class
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      <AlertDialog 
        open={deleteClass !== null} 
        onOpenChange={(open) => !open && setDeleteClass(null)}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action will permanently delete this class.
              Make sure there are no students assigned to this class before deleting.
              This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              className="bg-red-500 hover:bg-red-600"
              onClick={handleDeleteConfirm}
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
