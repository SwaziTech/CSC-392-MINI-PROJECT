import { useState } from "react";
import { StatsCards } from "@/components/dashboard/StatsCards";
import { AttendanceChart } from "@/components/dashboard/AttendanceChart";
import { RecentClasses } from "@/components/dashboard/RecentClasses";
import { AttendanceTable } from "@/components/dashboard/AttendanceTable";
import { QuickActions } from "@/components/dashboard/QuickActions";
import { AbsenceNotes } from "@/components/dashboard/AbsenceNotes";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { TakeAttendanceModal } from "@/components/attendance/TakeAttendanceModal";
import { useAuth } from "@/hooks/useAuth";

export default function Dashboard() {
  const [showAttendanceModal, setShowAttendanceModal] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const { user } = useAuth();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    console.log("Searching for:", searchQuery);
  };

  return (
    <>
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between mb-6">
        <div>
          <h2 className="text-2xl font-semibold text-gray-800">Dashboard</h2>
          <p className="text-sm text-gray-600 mt-1">
            Attendance overview for Mountain View High School
          </p>
        </div>
        <div className="mt-4 lg:mt-0 flex flex-col sm:flex-row gap-2">
          <form onSubmit={handleSearch} className="relative">
            <Input
              type="text"
              className="pl-9 pr-4 py-2 w-full lg:w-auto"
              placeholder="Search student..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
            <i className="fas fa-search absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"></i>
          </form>
          <Button onClick={() => setShowAttendanceModal(true)}>
            <i className="fas fa-plus mr-2"></i>
            <span>Take Attendance</span>
          </Button>
        </div>
      </div>

      <StatsCards />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
        <AttendanceChart />
        <RecentClasses />
      </div>

      <AttendanceTable />

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <QuickActions />
        <AbsenceNotes />
      </div>

      <TakeAttendanceModal 
        open={showAttendanceModal} 
        onOpenChange={setShowAttendanceModal} 
      />
    </>
  );
}
