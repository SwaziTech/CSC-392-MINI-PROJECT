import {
  User,
  InsertUser,
  Student,
  InsertStudent,
  Class,
  InsertClass,
  Attendance,
  InsertAttendance,
  AbsenceNote,
  InsertAbsenceNote,
} from "@shared/schema";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Student operations
  getStudents(): Promise<Student[]>;
  getStudent(id: number): Promise<Student | undefined>;
  getStudentByStudentId(studentId: string): Promise<Student | undefined>;
  getStudentsByClass(classId: number): Promise<Student[]>;
  createStudent(student: InsertStudent): Promise<Student>;
  updateStudent(id: number, student: Partial<InsertStudent>): Promise<Student | undefined>;
  deleteStudent(id: number): Promise<boolean>;
  
  // Class operations
  getClasses(): Promise<Class[]>;
  getClass(id: number): Promise<Class | undefined>;
  getClassesByTeacher(teacherId: number): Promise<Class[]>;
  createClass(classData: InsertClass): Promise<Class>;
  updateClass(id: number, classData: Partial<InsertClass>): Promise<Class | undefined>;
  deleteClass(id: number): Promise<boolean>;
  
  // Attendance operations
  getAttendances(): Promise<Attendance[]>;
  getAttendanceById(id: number): Promise<Attendance | undefined>;
  getAttendancesByDate(date: Date): Promise<Attendance[]>;
  getAttendancesByDateAndClass(date: Date, classId: number): Promise<Attendance[]>;
  getAttendancesByStudent(studentId: number): Promise<Attendance[]>;
  getAttendancesByStudentAndDateRange(studentId: number, startDate: Date, endDate: Date): Promise<Attendance[]>;
  createAttendance(attendance: InsertAttendance): Promise<Attendance>;
  updateAttendance(id: number, attendance: Partial<InsertAttendance>): Promise<Attendance | undefined>;
  deleteAttendance(id: number): Promise<boolean>;

  // Absence notes operations
  getAbsenceNotes(): Promise<AbsenceNote[]>;
  getAbsenceNoteById(id: number): Promise<AbsenceNote | undefined>;
  getAbsenceNotesByStudent(studentId: number): Promise<AbsenceNote[]>;
  createAbsenceNote(absenceNote: InsertAbsenceNote): Promise<AbsenceNote>;
  updateAbsenceNote(id: number, absenceNote: Partial<InsertAbsenceNote>): Promise<AbsenceNote | undefined>;
  deleteAbsenceNote(id: number): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private students: Map<number, Student>;
  private classes: Map<number, Class>;
  private attendances: Map<number, Attendance>;
  private absenceNotes: Map<number, AbsenceNote>;
  
  private currentUserId: number;
  private currentStudentId: number;
  private currentClassId: number;
  private currentAttendanceId: number;
  private currentAbsenceNoteId: number;

  constructor() {
    this.users = new Map();
    this.students = new Map();
    this.classes = new Map();
    this.attendances = new Map();
    this.absenceNotes = new Map();
    
    this.currentUserId = 1;
    this.currentStudentId = 1;
    this.currentClassId = 1;
    this.currentAttendanceId = 1;
    this.currentAbsenceNoteId = 1;
    
    // Add default admin user
    this.createUser({
      username: "admin",
      password: "password123", // In a real app, this would be hashed
      name: "John Anderson",
      email: "admin@school.edu",
      role: "teacher"
    });
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }
  
  // Student operations
  async getStudents(): Promise<Student[]> {
    return Array.from(this.students.values());
  }
  
  async getStudent(id: number): Promise<Student | undefined> {
    return this.students.get(id);
  }
  
  async getStudentByStudentId(studentId: string): Promise<Student | undefined> {
    return Array.from(this.students.values()).find(
      (student) => student.studentId === studentId
    );
  }
  
  async getStudentsByClass(classId: number): Promise<Student[]> {
    return Array.from(this.students.values()).filter(
      (student) => student.classId === classId
    );
  }
  
  async createStudent(insertStudent: InsertStudent): Promise<Student> {
    const id = this.currentStudentId++;
    const student: Student = { ...insertStudent, id };
    this.students.set(id, student);
    return student;
  }
  
  async updateStudent(id: number, updateData: Partial<InsertStudent>): Promise<Student | undefined> {
    const student = this.students.get(id);
    if (!student) return undefined;
    
    const updatedStudent = { ...student, ...updateData };
    this.students.set(id, updatedStudent);
    return updatedStudent;
  }
  
  async deleteStudent(id: number): Promise<boolean> {
    return this.students.delete(id);
  }
  
  // Class operations
  async getClasses(): Promise<Class[]> {
    return Array.from(this.classes.values());
  }
  
  async getClass(id: number): Promise<Class | undefined> {
    return this.classes.get(id);
  }
  
  async getClassesByTeacher(teacherId: number): Promise<Class[]> {
    return Array.from(this.classes.values()).filter(
      (cls) => cls.teacherId === teacherId
    );
  }
  
  async createClass(insertClass: InsertClass): Promise<Class> {
    const id = this.currentClassId++;
    const classData: Class = { ...insertClass, id };
    this.classes.set(id, classData);
    return classData;
  }
  
  async updateClass(id: number, updateData: Partial<InsertClass>): Promise<Class | undefined> {
    const classData = this.classes.get(id);
    if (!classData) return undefined;
    
    const updatedClass = { ...classData, ...updateData };
    this.classes.set(id, updatedClass);
    return updatedClass;
  }
  
  async deleteClass(id: number): Promise<boolean> {
    return this.classes.delete(id);
  }
  
  // Attendance operations
  async getAttendances(): Promise<Attendance[]> {
    return Array.from(this.attendances.values());
  }
  
  async getAttendanceById(id: number): Promise<Attendance | undefined> {
    return this.attendances.get(id);
  }
  
  async getAttendancesByDate(date: Date): Promise<Attendance[]> {
    const targetDate = new Date(date);
    targetDate.setHours(0, 0, 0, 0);
    
    return Array.from(this.attendances.values()).filter(attendance => {
      const attendanceDate = new Date(attendance.date);
      attendanceDate.setHours(0, 0, 0, 0);
      return attendanceDate.getTime() === targetDate.getTime();
    });
  }
  
  async getAttendancesByDateAndClass(date: Date, classId: number): Promise<Attendance[]> {
    const targetDate = new Date(date);
    targetDate.setHours(0, 0, 0, 0);
    
    return Array.from(this.attendances.values()).filter(attendance => {
      const attendanceDate = new Date(attendance.date);
      attendanceDate.setHours(0, 0, 0, 0);
      return attendanceDate.getTime() === targetDate.getTime() && attendance.classId === classId;
    });
  }
  
  async getAttendancesByStudent(studentId: number): Promise<Attendance[]> {
    return Array.from(this.attendances.values()).filter(
      (attendance) => attendance.studentId === studentId
    );
  }
  
  async getAttendancesByStudentAndDateRange(studentId: number, startDate: Date, endDate: Date): Promise<Attendance[]> {
    const start = new Date(startDate);
    start.setHours(0, 0, 0, 0);
    
    const end = new Date(endDate);
    end.setHours(23, 59, 59, 999);
    
    return Array.from(this.attendances.values()).filter(attendance => {
      const attendanceDate = new Date(attendance.date);
      return (
        attendance.studentId === studentId &&
        attendanceDate >= start &&
        attendanceDate <= end
      );
    });
  }
  
  async createAttendance(insertAttendance: InsertAttendance): Promise<Attendance> {
    const id = this.currentAttendanceId++;
    const attendance: Attendance = { ...insertAttendance, id };
    this.attendances.set(id, attendance);
    return attendance;
  }
  
  async updateAttendance(id: number, updateData: Partial<InsertAttendance>): Promise<Attendance | undefined> {
    const attendance = this.attendances.get(id);
    if (!attendance) return undefined;
    
    const updatedAttendance = { ...attendance, ...updateData };
    this.attendances.set(id, updatedAttendance);
    return updatedAttendance;
  }
  
  async deleteAttendance(id: number): Promise<boolean> {
    return this.attendances.delete(id);
  }
  
  // Absence notes operations
  async getAbsenceNotes(): Promise<AbsenceNote[]> {
    return Array.from(this.absenceNotes.values());
  }
  
  async getAbsenceNoteById(id: number): Promise<AbsenceNote | undefined> {
    return this.absenceNotes.get(id);
  }
  
  async getAbsenceNotesByStudent(studentId: number): Promise<AbsenceNote[]> {
    return Array.from(this.absenceNotes.values()).filter(
      (note) => note.studentId === studentId
    );
  }
  
  async createAbsenceNote(insertAbsenceNote: InsertAbsenceNote): Promise<AbsenceNote> {
    const id = this.currentAbsenceNoteId++;
    const absenceNote: AbsenceNote = { ...insertAbsenceNote, id };
    this.absenceNotes.set(id, absenceNote);
    return absenceNote;
  }
  
  async updateAbsenceNote(id: number, updateData: Partial<InsertAbsenceNote>): Promise<AbsenceNote | undefined> {
    const absenceNote = this.absenceNotes.get(id);
    if (!absenceNote) return undefined;
    
    const updatedAbsenceNote = { ...absenceNote, ...updateData };
    this.absenceNotes.set(id, updatedAbsenceNote);
    return updatedAbsenceNote;
  }
  
  async deleteAbsenceNote(id: number): Promise<boolean> {
    return this.absenceNotes.delete(id);
  }
}

export const storage = new MemStorage();
