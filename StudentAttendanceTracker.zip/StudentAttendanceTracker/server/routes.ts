import express, { type Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import session from "express-session";
import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import { z } from "zod";
import { 
  loginSchema, 
  insertUserSchema, 
  insertStudentSchema, 
  insertClassSchema, 
  insertAttendanceSchema, 
  insertAbsenceNoteSchema 
} from "@shared/schema";
import MemoryStore from "memorystore";

function formatValidationError(error: z.ZodError) {
  return error.errors.map(err => ({
    path: err.path.join('.'),
    message: err.message
  }));
}

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);
  const MemoryStoreSession = MemoryStore(session);

  // Setup session
  app.use(
    session({
      secret: "attendance-system-secret",
      resave: false,
      saveUninitialized: false,
      store: new MemoryStoreSession({
        checkPeriod: 86400000 // 24 hours
      }),
      cookie: { 
        maxAge: 24 * 60 * 60 * 1000, // 24 hours
        secure: process.env.NODE_ENV === "production" 
      }
    })
  );

  // Setup passport
  app.use(passport.initialize());
  app.use(passport.session());

  passport.use(
    new LocalStrategy(async (username, password, done) => {
      try {
        const user = await storage.getUserByUsername(username);
        if (!user) {
          return done(null, false, { message: "Incorrect username" });
        }
        if (user.password !== password) { // In real app would use bcrypt.compare
          return done(null, false, { message: "Incorrect password" });
        }
        return done(null, user);
      } catch (err) {
        return done(err);
      }
    })
  );

  passport.serializeUser((user: any, done) => {
    done(null, user.id);
  });

  passport.deserializeUser(async (id: number, done) => {
    try {
      const user = await storage.getUser(id);
      done(null, user);
    } catch (err) {
      done(err);
    }
  });

  // Authentication middleware
  const isAuthenticated = (req: Request, res: Response, next: express.NextFunction) => {
    if (req.isAuthenticated()) {
      return next();
    }
    res.status(401).json({ message: "Unauthorized" });
  };

  // Auth routes
  app.post("/api/auth/login", (req, res, next) => {
    try {
      const { username, password } = loginSchema.parse(req.body);
      
      passport.authenticate("local", (err: any, user: any, info: any) => {
        if (err) {
          return next(err);
        }
        if (!user) {
          return res.status(400).json({ message: info.message });
        }
        req.logIn(user, (err) => {
          if (err) {
            return next(err);
          }
          return res.json({ 
            id: user.id, 
            username: user.username, 
            name: user.name, 
            email: user.email, 
            role: user.role 
          });
        });
      })(req, res, next);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Validation error", 
          errors: formatValidationError(error) 
        });
      }
      next(error);
    }
  });

  app.post("/api/auth/register", async (req, res, next) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      const existingUser = await storage.getUserByUsername(userData.username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }
      
      const user = await storage.createUser(userData);
      return res.status(201).json({ 
        id: user.id, 
        username: user.username, 
        name: user.name, 
        email: user.email, 
        role: user.role 
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Validation error", 
          errors: formatValidationError(error) 
        });
      }
      next(error);
    }
  });

  app.get("/api/auth/me", isAuthenticated, (req, res) => {
    const user = req.user as any;
    res.json({ 
      id: user.id, 
      username: user.username, 
      name: user.name, 
      email: user.email, 
      role: user.role 
    });
  });

  app.post("/api/auth/logout", isAuthenticated, (req, res) => {
    req.logout(() => {
      res.json({ message: "Logged out successfully" });
    });
  });

  // Student routes
  app.get("/api/students", isAuthenticated, async (req, res, next) => {
    try {
      const students = await storage.getStudents();
      res.json(students);
    } catch (error) {
      next(error);
    }
  });

  app.get("/api/students/:id", isAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id, 10);
      const student = await storage.getStudent(id);
      
      if (!student) {
        return res.status(404).json({ message: "Student not found" });
      }
      
      res.json(student);
    } catch (error) {
      next(error);
    }
  });

  app.get("/api/classes/:classId/students", isAuthenticated, async (req, res, next) => {
    try {
      const classId = parseInt(req.params.classId, 10);
      const students = await storage.getStudentsByClass(classId);
      res.json(students);
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/students", isAuthenticated, async (req, res, next) => {
    try {
      const studentData = insertStudentSchema.parse(req.body);
      
      const existingStudent = await storage.getStudentByStudentId(studentData.studentId);
      if (existingStudent) {
        return res.status(400).json({ message: "Student ID already exists" });
      }
      
      const student = await storage.createStudent(studentData);
      res.status(201).json(student);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Validation error", 
          errors: formatValidationError(error) 
        });
      }
      next(error);
    }
  });

  app.put("/api/students/:id", isAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id, 10);
      const updateData = insertStudentSchema.partial().parse(req.body);
      
      const updatedStudent = await storage.updateStudent(id, updateData);
      
      if (!updatedStudent) {
        return res.status(404).json({ message: "Student not found" });
      }
      
      res.json(updatedStudent);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Validation error", 
          errors: formatValidationError(error) 
        });
      }
      next(error);
    }
  });

  app.delete("/api/students/:id", isAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id, 10);
      const success = await storage.deleteStudent(id);
      
      if (!success) {
        return res.status(404).json({ message: "Student not found" });
      }
      
      res.json({ message: "Student deleted successfully" });
    } catch (error) {
      next(error);
    }
  });

  // Class routes
  app.get("/api/classes", isAuthenticated, async (req, res, next) => {
    try {
      const classes = await storage.getClasses();
      res.json(classes);
    } catch (error) {
      next(error);
    }
  });

  app.get("/api/classes/:id", isAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id, 10);
      const classData = await storage.getClass(id);
      
      if (!classData) {
        return res.status(404).json({ message: "Class not found" });
      }
      
      res.json(classData);
    } catch (error) {
      next(error);
    }
  });

  app.get("/api/teachers/:teacherId/classes", isAuthenticated, async (req, res, next) => {
    try {
      const teacherId = parseInt(req.params.teacherId, 10);
      const classes = await storage.getClassesByTeacher(teacherId);
      res.json(classes);
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/classes", isAuthenticated, async (req, res, next) => {
    try {
      const classData = insertClassSchema.parse(req.body);
      const createdClass = await storage.createClass(classData);
      res.status(201).json(createdClass);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Validation error", 
          errors: formatValidationError(error) 
        });
      }
      next(error);
    }
  });

  app.put("/api/classes/:id", isAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id, 10);
      const updateData = insertClassSchema.partial().parse(req.body);
      
      const updatedClass = await storage.updateClass(id, updateData);
      
      if (!updatedClass) {
        return res.status(404).json({ message: "Class not found" });
      }
      
      res.json(updatedClass);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Validation error", 
          errors: formatValidationError(error) 
        });
      }
      next(error);
    }
  });

  app.delete("/api/classes/:id", isAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id, 10);
      const success = await storage.deleteClass(id);
      
      if (!success) {
        return res.status(404).json({ message: "Class not found" });
      }
      
      res.json({ message: "Class deleted successfully" });
    } catch (error) {
      next(error);
    }
  });

  // Attendance routes
  app.get("/api/attendance", isAuthenticated, async (req, res, next) => {
    try {
      const date = req.query.date ? new Date(req.query.date as string) : new Date();
      const classId = req.query.classId ? parseInt(req.query.classId as string, 10) : undefined;
      
      let attendances;
      if (classId) {
        attendances = await storage.getAttendancesByDateAndClass(date, classId);
      } else {
        attendances = await storage.getAttendancesByDate(date);
      }
      
      res.json(attendances);
    } catch (error) {
      next(error);
    }
  });

  app.get("/api/attendance/:id", isAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id, 10);
      const attendance = await storage.getAttendanceById(id);
      
      if (!attendance) {
        return res.status(404).json({ message: "Attendance record not found" });
      }
      
      res.json(attendance);
    } catch (error) {
      next(error);
    }
  });

  app.get("/api/students/:studentId/attendance", isAuthenticated, async (req, res, next) => {
    try {
      const studentId = parseInt(req.params.studentId, 10);
      const startDate = req.query.startDate ? new Date(req.query.startDate as string) : undefined;
      const endDate = req.query.endDate ? new Date(req.query.endDate as string) : undefined;
      
      let attendances;
      if (startDate && endDate) {
        attendances = await storage.getAttendancesByStudentAndDateRange(studentId, startDate, endDate);
      } else {
        attendances = await storage.getAttendancesByStudent(studentId);
      }
      
      res.json(attendances);
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/attendance", isAuthenticated, async (req, res, next) => {
    try {
      const attendanceData = insertAttendanceSchema.parse(req.body);
      const attendance = await storage.createAttendance(attendanceData);
      res.status(201).json(attendance);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Validation error", 
          errors: formatValidationError(error) 
        });
      }
      next(error);
    }
  });

  app.post("/api/attendance/bulk", isAuthenticated, async (req, res, next) => {
    try {
      const { attendances } = req.body;
      
      if (!Array.isArray(attendances)) {
        return res.status(400).json({ message: "Invalid attendances data" });
      }
      
      const results = [];
      for (const data of attendances) {
        const attendanceData = insertAttendanceSchema.parse(data);
        const attendance = await storage.createAttendance(attendanceData);
        results.push(attendance);
      }
      
      res.status(201).json(results);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Validation error", 
          errors: formatValidationError(error) 
        });
      }
      next(error);
    }
  });

  app.put("/api/attendance/:id", isAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id, 10);
      const updateData = insertAttendanceSchema.partial().parse(req.body);
      
      const updatedAttendance = await storage.updateAttendance(id, updateData);
      
      if (!updatedAttendance) {
        return res.status(404).json({ message: "Attendance record not found" });
      }
      
      res.json(updatedAttendance);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Validation error", 
          errors: formatValidationError(error) 
        });
      }
      next(error);
    }
  });

  app.delete("/api/attendance/:id", isAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id, 10);
      const success = await storage.deleteAttendance(id);
      
      if (!success) {
        return res.status(404).json({ message: "Attendance record not found" });
      }
      
      res.json({ message: "Attendance record deleted successfully" });
    } catch (error) {
      next(error);
    }
  });

  // Absence notes routes
  app.get("/api/absence-notes", isAuthenticated, async (req, res, next) => {
    try {
      const absenceNotes = await storage.getAbsenceNotes();
      res.json(absenceNotes);
    } catch (error) {
      next(error);
    }
  });

  app.get("/api/absence-notes/:id", isAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id, 10);
      const absenceNote = await storage.getAbsenceNoteById(id);
      
      if (!absenceNote) {
        return res.status(404).json({ message: "Absence note not found" });
      }
      
      res.json(absenceNote);
    } catch (error) {
      next(error);
    }
  });

  app.get("/api/students/:studentId/absence-notes", isAuthenticated, async (req, res, next) => {
    try {
      const studentId = parseInt(req.params.studentId, 10);
      const absenceNotes = await storage.getAbsenceNotesByStudent(studentId);
      res.json(absenceNotes);
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/absence-notes", isAuthenticated, async (req, res, next) => {
    try {
      const absenceNoteData = insertAbsenceNoteSchema.parse(req.body);
      const absenceNote = await storage.createAbsenceNote(absenceNoteData);
      res.status(201).json(absenceNote);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Validation error", 
          errors: formatValidationError(error) 
        });
      }
      next(error);
    }
  });

  app.put("/api/absence-notes/:id", isAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id, 10);
      const updateData = insertAbsenceNoteSchema.partial().parse(req.body);
      
      const updatedAbsenceNote = await storage.updateAbsenceNote(id, updateData);
      
      if (!updatedAbsenceNote) {
        return res.status(404).json({ message: "Absence note not found" });
      }
      
      res.json(updatedAbsenceNote);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Validation error", 
          errors: formatValidationError(error) 
        });
      }
      next(error);
    }
  });

  app.delete("/api/absence-notes/:id", isAuthenticated, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id, 10);
      const success = await storage.deleteAbsenceNote(id);
      
      if (!success) {
        return res.status(404).json({ message: "Absence note not found" });
      }
      
      res.json({ message: "Absence note deleted successfully" });
    } catch (error) {
      next(error);
    }
  });

  // Stats and dashboard data
  app.get("/api/stats/today", isAuthenticated, async (req, res, next) => {
    try {
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      
      const attendances = await storage.getAttendancesByDate(today);
      
      const total = attendances.length;
      const present = attendances.filter(a => a.status === "present").length;
      const absent = attendances.filter(a => a.status === "absent").length;
      const late = attendances.filter(a => a.status === "late").length;
      
      let presentPercentage = 0;
      let absentPercentage = 0;
      let latePercentage = 0;
      
      if (total > 0) {
        presentPercentage = (present / total) * 100;
        absentPercentage = (absent / total) * 100;
        latePercentage = (late / total) * 100;
      }
      
      res.json({
        total,
        present,
        absent,
        late,
        presentPercentage: presentPercentage.toFixed(1),
        absentPercentage: absentPercentage.toFixed(1),
        latePercentage: latePercentage.toFixed(1)
      });
    } catch (error) {
      next(error);
    }
  });

  app.get("/api/stats/trends", isAuthenticated, async (req, res, next) => {
    try {
      const days = parseInt(req.query.days as string || "7", 10);
      const result = [];
      
      for (let i = 0; i < days; i++) {
        const date = new Date();
        date.setDate(date.getDate() - i);
        date.setHours(0, 0, 0, 0);
        
        const attendances = await storage.getAttendancesByDate(date);
        
        const total = attendances.length;
        const present = attendances.filter(a => a.status === "present").length;
        const absent = attendances.filter(a => a.status === "absent").length;
        const late = attendances.filter(a => a.status === "late").length;
        
        let presentPercentage = 0;
        let absentPercentage = 0;
        let latePercentage = 0;
        
        if (total > 0) {
          presentPercentage = (present / total) * 100;
          absentPercentage = (absent / total) * 100;
          latePercentage = (late / total) * 100;
        }
        
        result.push({
          date: date.toISOString().split('T')[0],
          total,
          present,
          absent,
          late,
          presentPercentage: presentPercentage.toFixed(1),
          absentPercentage: absentPercentage.toFixed(1),
          latePercentage: latePercentage.toFixed(1)
        });
      }
      
      res.json(result.reverse());
    } catch (error) {
      next(error);
    }
  });

  app.get("/api/dashboard/recent-classes", isAuthenticated, async (req, res, next) => {
    try {
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      
      const attendances = await storage.getAttendancesByDate(today);
      const classes = await storage.getClasses();
      
      const classAttendance = new Map();
      
      for (const attendance of attendances) {
        const { classId, status } = attendance;
        
        if (!classAttendance.has(classId)) {
          classAttendance.set(classId, { present: 0, absent: 0, late: 0, total: 0 });
        }
        
        const stats = classAttendance.get(classId);
        stats.total++;
        
        if (status === "present") {
          stats.present++;
        } else if (status === "absent") {
          stats.absent++;
        } else if (status === "late") {
          stats.late++;
        }
      }
      
      const result = [];
      
      for (const [classId, stats] of classAttendance.entries()) {
        const classData = classes.find(c => c.id === classId);
        
        if (classData) {
          result.push({
            id: classData.id,
            name: classData.name,
            grade: classData.grade,
            section: classData.section,
            present: stats.present,
            absent: stats.absent,
            late: stats.late,
            total: stats.total
          });
        }
      }
      
      res.json(result);
    } catch (error) {
      next(error);
    }
  });

  return httpServer;
}
