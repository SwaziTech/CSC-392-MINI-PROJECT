import { pgTable, text, serial, integer, timestamp, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User schema
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  role: text("role").notNull().default("teacher"),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  name: true,
  email: true,
  role: true,
});

// Student schema
export const students = pgTable("students", {
  id: serial("id").primaryKey(),
  studentId: text("student_id").notNull().unique(),
  name: text("name").notNull(),
  email: text("email"),
  classId: integer("class_id").notNull(),
});

export const insertStudentSchema = createInsertSchema(students).pick({
  studentId: true,
  name: true,
  email: true,
  classId: true,
});

// Class schema
export const classes = pgTable("classes", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  grade: text("grade").notNull(),
  section: text("section").notNull(),
  teacherId: integer("teacher_id").notNull(),
});

export const insertClassSchema = createInsertSchema(classes).pick({
  name: true,
  grade: true,
  section: true,
  teacherId: true,
});

// Attendance schema
export const attendances = pgTable("attendances", {
  id: serial("id").primaryKey(),
  studentId: integer("student_id").notNull(),
  classId: integer("class_id").notNull(),
  date: timestamp("date").notNull(),
  status: text("status").notNull(), // "present", "absent", "late"
  note: text("note"),
  recordedBy: integer("recorded_by").notNull(),
});

export const insertAttendanceSchema = createInsertSchema(attendances).pick({
  studentId: true,
  classId: true,
  date: true,
  status: true,
  note: true,
  recordedBy: true,
});

// Absence notes schema
export const absenceNotes = pgTable("absence_notes", {
  id: serial("id").primaryKey(),
  studentId: integer("student_id").notNull(),
  date: timestamp("date").notNull(),
  note: text("note").notNull(),
  status: text("status").notNull().default("pending"), // "pending", "approved", "declined"
  submittedBy: integer("submitted_by").notNull(),
});

export const insertAbsenceNoteSchema = createInsertSchema(absenceNotes).pick({
  studentId: true,
  date: true,
  note: true,
  status: true,
  submittedBy: true,
});

// Export types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertStudent = z.infer<typeof insertStudentSchema>;
export type Student = typeof students.$inferSelect;

export type InsertClass = z.infer<typeof insertClassSchema>;
export type Class = typeof classes.$inferSelect;

export type InsertAttendance = z.infer<typeof insertAttendanceSchema>;
export type Attendance = typeof attendances.$inferSelect;

export type InsertAbsenceNote = z.infer<typeof insertAbsenceNoteSchema>;
export type AbsenceNote = typeof absenceNotes.$inferSelect;

// Validation schemas for login
export const loginSchema = z.object({
  username: z.string().min(3, "Username must be at least 3 characters"),
  password: z.string().min(6, "Password must be at least 6 characters"),
});

// Type for authentication
export type LoginCredentials = z.infer<typeof loginSchema>;
